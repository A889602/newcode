from django.shortcuts import render,redirect,HttpResponse
from django.contrib.auth.models import User
from django.contrib.auth import authenticate,login, logout
from django.contrib import messages


# Create your views here.
def home(request):
    return render(request,'home.html')
def register(request):
    if request.method=='POST':
        username=request.POST['username']
        email=request.POST['email']
        Password=request.POST['password']
        myuser=User.objects.create_user(username,email,Password)
        myuser.save()
        messages.success(request,'Registered successfully...')
        return redirect('login')

    return render(request,'signup.html')

def log(request):
    if request.method=="POST":
        username=request.POST['username']
        password=request.POST['password']
        user=authenticate(username=username,password=password)
        
        if user is not None:
            login(request,user)
            return redirect('home')
        else:
            messages.warning(request,'Invalid Username or Password')
    return render(request,'login.html')

def log_out(request):
    if request.user.is_authenticated:
        logout(request)
    return redirect('login')