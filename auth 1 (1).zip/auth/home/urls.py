from django.contrib import admin
from django.urls import path
from home import views
urlpatterns = [
    path('',views.register,name='register'),
    path('home',views.home, name='home'),
    path('login',views.log, name='login'),
    path('lgout',views.log_out, name='logout'),
]